import React from "react";
import TodosListItem from "../TodosListItem/TodosListItem";

export default function TodosList({ status, tasks, handleStatusChange, handleDelete }) {
  return (
    <div className="todos-list">
      <h2>{status.title}</h2>
      {tasks.map((task) => (
        <TodosListItem
          key={task.id}
          task={task}
          handleStatusChange={handleStatusChange}
          handleDelete={handleDelete}
        />
      ))}
    </div>
  );
}