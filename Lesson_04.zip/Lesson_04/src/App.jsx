import React from 'react';
import Todos from './components/Todos/Todos';

export default function App() {
  return (
    <>
      <Todos />
    </>
  );
}