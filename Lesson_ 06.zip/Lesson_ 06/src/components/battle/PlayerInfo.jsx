import React from "react";
import Button from "../Button";

export default function PlayerInfo({ player, onReset }) {
  return (
    <div style={{ margin: "1em", textAlign: "center" }}>
      <img
        src={player.avatar_url}
        alt={player.login}
        style={{ width: "100px", borderRadius: "50%" }}
      />
      <p>{player.login}</p>
      <Button title="Reset" handleClick={onReset} />
    </div>
  );
}