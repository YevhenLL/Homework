import React from "react";
import Button from "../Button";

export default function BattleResult({ players, onRestart }) {
  const [player1, player2] = players;

  const totalScore1 = player1.followers + player1.stars;
  const totalScore2 = player2.followers + player2.stars;

  return (
    <div style={{ margin: "1em", textAlign: "center" }}>
      <h2>{totalScore1 > totalScore2 ? "Winner 🥳" : "Loser 🥵"}</h2>
      <h2>{totalScore2 > totalScore1 ? "Winner 🥳" : "Loser 🥵"}</h2>
      <Button title="Restart 🔄" handleClick={onRestart} />
    </div>
  );
}