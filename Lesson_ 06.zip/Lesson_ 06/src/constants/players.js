export const PLAYERS = [
    {
      id: 1,
      label: "Choose Player 1 username",
      placeholder: "Player 1",
    },
    {
      id: 2,
      label: "Choose Player 2 username",
      placeholder: "Player 2",
    },
  ];