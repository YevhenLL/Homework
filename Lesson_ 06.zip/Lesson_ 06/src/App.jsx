import React from "react";
import Battle from "./components/battle/Battle";

export default function App() {
  return <Battle />;
}