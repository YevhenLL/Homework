import React from "react";

export default function Button({ title, handleClick }) {
  return (
    <button onClick={handleClick} style={{ margin: "0.5em" }}>
      {title}
    </button>
  );
}