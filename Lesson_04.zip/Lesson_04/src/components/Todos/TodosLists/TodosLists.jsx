import React from "react";
import TodosList from "../TodosList/TodosList";
import TodosForm from "../TodosForm/TodosForm"; // Revert the import path

export default function TodosLists({ tasks, handleStatusChange, handleDelete, handleTaskCreate }) {
  const statuses = [
    { id: 0, title: "To Do" },
    { id: 1, title: "In Progress" },
    { id: 2, title: "Done" },
    { id: 4, title: "On Hold" }, // Додано новий статус
  ];

  return (
    <div className="todos-lists-container">
      <TodosForm handleTaskCreate={handleTaskCreate} /> {/* Форма відображається тут */}
      <div className="todos-lists" style={{ display: "flex" }}>
        {statuses.map((status) => (
          <div key={status.id} style={{ flex: 1, margin: "0 10px" }}>
            <TodosList
              status={status}
              tasks={tasks.filter((task) => task.status === status.id)}
              handleStatusChange={handleStatusChange}
              handleDelete={handleDelete}
            />
          </div>
        ))}
      </div>
    </div>
  );
}