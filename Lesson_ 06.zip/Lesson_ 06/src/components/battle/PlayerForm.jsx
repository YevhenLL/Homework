import React from "react";
import Button from "../Button";

export default function PlayerForm({ player, onSubmit, error }) {
  return (
    <div style={{ margin: "1em", textAlign: "center" }}>
      <form
        onSubmit={onSubmit}
        style={{ display: "flex", flexDirection: "column", gap: "0.5em" }}
      >
        <label>{player.label}</label>
        <input type="text" placeholder={player.placeholder} />
        <Button title="Submit" handleClick={onSubmit} />
      </form>
      {error && <p style={{ color: "red" }}>{error}</p>}
    </div>
  );
}